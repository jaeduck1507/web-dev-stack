package config;

public interface ServerInfo {
	String DRIVER = "com.mysql.cj.jdbc.Driver";
	String URL = "jdbc:mysql://localhost:3306/work";
	String USER = "root";
	String PASSWORD = "qwer1234";
}